$(function(){
$('#linguistics_DIV').hover(function(){
$('#linguistics_inside').fadeToggle(400);
});

$('#linguistics_DIV-2').hover(function(){
$('#linguistics_inside-2').fadeToggle(400);
});

$('#linguistics_DIV-3').hover(function(){
$('#linguistics_inside-3').fadeToggle(400);
});

$('#linguistics_DIV-4').hover(function(){
$('#linguistics_inside-4').fadeToggle(400);
});

$('#firstpost').hover(function(){
$('#firstcontent').fadeToggle(500);
});

$('#secondpost').hover(function(){
$('#secondcontent').fadeToggle(500);
});

$('#thirdpost').hover(function(){
$('#thirdcontent').fadeToggle(500);
});

$('#fourthpost').hover(function(){
$('#fourthcontent').fadeToggle(500);
});
});
